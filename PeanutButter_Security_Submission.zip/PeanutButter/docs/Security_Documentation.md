## SECURITY Svcs | Security Documentation

Implementation and verification record | 17 November 2026 | Group members / section: fill in before submission.

Basis: Machine Project Specifications - Security Svcs.pdf; Machine Project Checklist - Security Svcs.pdf (Rev. 02-2026); attached starter source ZIP; owensanluis/PeanutButter main at 110f7d3a519dacaf8fb70e01d16b1675525aa705. This is a Java Swing desktop application, so checklist pages/requests are implemented as panels and service operations, not HTTP routes.

Outcome: implemented the missing security and business operations, preserved the existing NetBeans screens/project, and built a standalone distribution. Observed: 140 automated checks pass against real temporary SQLite databases; a separate packaged-JAR smoke test passes. This record does not assign a grade or certify the unperformed Windows/NetBeans desktop demo.

## 1. Baseline findings and implementation scope

| Finding in the supplied repository | Resulting fix |
| --- | --- |
| Source could not compile: dangling statement, undefined fields/types and incompatible constructor/method calls in Frame, Login and Register. | Reconnected the existing Swing button handlers to a consistent service API; compiled the full source. |
| The new authentication helpers were not the handlers called by the existing UI. Password hashing used an unsupported algorithm name; database SQL had missing spaces. | Actual login/register actions now invoke working authentication and registration; standard PBKDF2WithHmacSHA256 is used. |
| Plaintext demo credentials, missing migrations and stale executable JAR. | Fresh hashed fixture, independent/idempotent schema migrations and rebuilt JAR. Legacy plaintext credentials are invalidated and disabled. |
| All roles could reach every home; product/user action listeners often only printed values. | Shared allowlist checks protect navigation and service calls; product CRUD, purchases, user role/lock/delete/reset and log management now work. |
| History exposed all customers and calculated totals from current product prices. | Stable account ownership and immutable purchase price snapshots prevent cross-account access and preserve history after product edits/deletion. |
| No required security documentation, ACL or live-demo test set. | This document follows all three prescribed table formats and maps all 29 checklist rows. |

## 2. Security modifications (required Table 4 format)

| Security requirement / issue | Added / modified files | Vulnerability | Impact | Security control |
| --- | --- | --- | --- | --- |
| 2.1.1; 2.2.1-4 Authentication and authorization | AccessControl.java; SQLite.java; Frame.java; all four *Home.java; Mgmt*.java | Unrestricted navigation and direct data operations; trust in UI visibility or mutable user objects. | An unauthenticated user or lower role could manage accounts, inspect logs, or read another customer's history. | One default-deny resource allowlist. Each protected service call reloads role, lock and session_version by private session ID in its transaction. Panel routes reuse the same policy. Role 1, missing accounts, invalid resources and errors deny. Session changes invalidate old sessions. UI visibility is only a convenience. |
| 2.1.2; 2.1.4 Generic secure login | SQLite.java; Login.java; Frame.java | Broken authentication queries and distinct account/disabled/error responses. | An attacker could enumerate accounts or reach a dashboard without verified credentials. | Private authentication returns one success/failure result; all login failures display exactly "Invalid username and/or password". Session is cleared before login and on failures. Missing users use a dummy PBKDF2 hash to avoid the obvious no-hash shortcut. This is not a formal timing-side-channel guarantee. |
| 2.1.3 Credential storage | PasswordUtils.java; SQLite.java; database.db; dist/database.db | Plaintext passwords and unsupported SecretKeyFactory algorithm. | A database reader could recover every password immediately; registration/login could fail. | PBKDF2WithHmacSHA256, 600000 iterations, SecureRandom 16-byte salt per password, 256-bit derived key, Base64 versioned storage; MessageDigest.isEqual comparison. Hashes never appear in user lists. Old credentials become random hashes and disabled accounts. secure_delete is enabled on connections. |
| 2.1.5-6 Password policy | SQLite.java; Register.java; PasswordDialog.java | No reliable password policy or maximum length in the actual handlers. | Weak credentials and oversized inputs could undermine authentication or stability. | 8-64 printable ASCII characters; uppercase, lowercase, digit and nonalphanumeric symbol; no whitespace; confirmation must match exactly. Registration, self-change and admin reset use the same validator. Invalid input is rejected and audited, never trimmed. |
| 2.1.7 Visual privacy | Login.java/.form; Register.java/.form; PasswordDialog.java; MgmtUser.java | Visible password text fields and console printing of entered passwords. | Shoulder-surfing, screenshots or terminal output could disclose credentials. | JPasswordField for login, registration, confirmation and every current/new-password dialog; fields clear after submission/cancel. User table receives only a fixed placeholder. Credential printing and runtime debug toggling removed. |
| 2.1.8 Five consecutive failures | SQLite.java; MgmtUser.java | No reliable persistent lockout; mismatched SQL prevented counter updates. | Repeated guessing could continue indefinitely. | Failure count persists in SQLite. Attempts 1-4 retain the active role; attempt 5 sets role=1 and locked=1. Successful authentication resets the count. Disabled users stay denied. Admin re-enables verified users and resets counts; prior active role is restored by unlock. Authentication and audit writes commit together. |
| 2.1.9 Previous account use | SQLite.java; Frame.java | Only last successful login was partially attempted; failure status was missing. | The user could not notice prior failed use of the account. | Store last_attempt and last_status for known accounts on both outcomes. Capture previous values before the successful login overwrites them. Show previous timestamp/status immediately after login, or "No previous account use." Timestamps use the workstation clock/timezone. |
| 2.1.10 Critical-operation reauthentication | SQLite.java; PasswordDialog.java; Frame.java; MgmtUser.java | Password changes were incomplete and had no fresh identity verification. | Someone using an unattended authenticated screen could take over an account. | Verify the acting user's current password inside the password-change transaction, immediately before updating. Admin resets require the admin password; self-change requires the user's own password. Reauthentication attempts are logged and counted. Password changes increment target session_version. Self-change logs out; failed reauthentication logs out. |
| 2.2.2 Least privilege and ownership | SQLite.java; AccessControl.java; MgmtHistory.java; History.java | Admin treated as superuser; history ownership based only on display name; current-price lookup. | Role abuse; a recreated username could inherit deleted-account history; historical totals could change or crash when products disappear. | Client purchase/history only; Staff product CRUD; Manager product CRUD/all history; Admin user/log management only. History reads filter by immutable user_id for clients, including searches. New purchases store unit_price and product name snapshots; manager can still read deleted-account history. |
| 2.3.1-3 Input rejection and bounds | SQLite.java; Register.java; MgmtProduct.java; MgmtUser.java; MgmtHistory.java | Inputs lacked consistent type/range/length checks and could be converted unsafely in listeners. | Malformed input could crash the UI or create invalid roles, negative stock or invalid prices. | Service validators use ASCII allowlist regexes and maximum lengths. Stock 0-100000, purchase 1-100000 within stock, price 0.01-1000000 with 2 decimals, role exactly 1-5. No trimming/sanitizing/truncating. A rejected operation does not partially apply business changes. See validation table. |
| 2.3.4 Parameterized database operations | SQLite.java | SQL built by concatenating usernames, product names, log descriptions and other values. | Inputs could change query structure, remove records or bypass intended filters. | All runtime SQL uses PreparedStatement; data values bind through setObject. Schema migration uses only fixed internal table/column/type identifiers (which cannot be SQL parameters). No user-controlled value forms SQL syntax. Resources close through try-with-resources. |
| 2.4.1-4 Controlled error handling | AppException.java; SQLite.java; Main.java; Frame.java; History.java; Logs.java | Console stack traces, swallowed SQL errors and unhandled Swing callback exceptions. | Internal paths/query details could leak; failures could appear successful or leave a privileged screen active. | Expected rejections use deliberately safe messages. Unexpected transactional failures roll back and clear the session. The Swing event boundary catches unhandled callbacks, clears privileged data and returns to Login. Startup failure shows a generic alert and no protected panel. No exception causes or stack traces are shown by the runtime. |
| 2.5.1 Admin-only security-log management | SQLite.java; AccessControl.java; AdminHome.java; MgmtLogs.java | Logs and debug toggle available to all roles; clear action incomplete. | Users could inspect security activity or destroy audit evidence. | Role 5 checks on every read/clear operation and panel entry. Clear requires UI confirmation, and leaves a fresh LOG_CLEAR record identifying the actor and timestamp. Refresh replaces debug mode. |
| 2.5.2-4 Security event auditing | SQLite.java; all protected navigation entry points | Missing validation/authentication/access-violation events; interpolated log SQL. | Repeated attacks and unauthorized requests would not leave useful evidence. | Timestamped VALIDATION_FAILURE, AUTH_SUCCESS, AUTH_FAILURE and ACCESS_VIOLATION events, plus account/product/purchase/password/log-management events. Use trusted event descriptions; never log raw passwords or hostile payloads. Audit writes share transactions with successful changes. An inaccessible database cannot persist logs; the operation fails closed. |
| Business correctness and distribution | SQLite.java; MgmtProduct.java; build.xml; build.sh/.bat; manifest.mf; dist/ | Purchases/actions were placeholders; stale binary and missing standalone database. | A visually complete demo could fail to persist operations, oversell stock or fail outside the IDE. | Purchase verifies stock and atomically decrements inventory/inserts history/audit. Conditional update prevents overselling; failure rolls back. Executable JAR bundles a manifest dependency path and uses database.db beside the JAR. NetBeans project and dependency retained. Fresh fixture has one account for each active role. |

## 3. Access Control Matrix (required Table 5 format)

| Feature / resource | Unregistered | Disabled (1) | Client (2) | Staff (3) | Manager (4) | Admin (5) |
| --- | --- | --- | --- | --- | --- | --- |
| Client Home | No | No | Yes | No | No | No |
| Staff Home | No | No | No | Yes | No | No |
| Manager Home | No | No | No | No | Yes | No |
| Admin Home | No | No | No | No | No | Yes |
| View product catalog | No | No | Yes | Yes | Yes | No |
| Purchase products | No | No | Yes | No | No | No |
| Add products | No | No | No | Yes | Yes | No |
| Edit products | No | No | No | Yes | Yes | No |
| Delete products | No | No | No | Yes | Yes | No |
| View/search own purchase history | No | No | Yes | No | Yes | No |
| View/search all purchase history | No | No | No | No | Yes | No |
| View user list | No | No | No | No | No | Yes |
| Assign role 1-5 | No | No | No | No | No | Yes |
| Disable/re-enable another user | No | No | No | No | No | Yes |
| Delete another user | No | No | No | No | No | Yes |
| Reset another password (reauthenticate) | No | No | No | No | No | Yes |
| Change own password (reauthenticate) | No | No | Yes | Yes | Yes | Yes |
| View/refresh security logs | No | No | No | No | No | Yes |
| Clear security logs | No | No | No | No | No | Yes |
| Logout | No | No | Yes | Yes | Yes | Yes |

All protected features are No for unregistered and disabled users. Login and Register are the explicit public exceptions: anyone can view them or submit an attempt, but a disabled account cannot authenticate. Public registration always creates Role 2; it cannot select a privileged role. The Change My Password menu may be visible before login, but invoking it is denied and audited. Admin cannot change its own role/lock state or delete itself; another administrator must do that. No role gains permissions by being numerically higher unless explicitly allowed above.

## 4. Demo Test Cases (required Table 6 format)

| Control group / ID | Test scenario | Expected outcome |
| --- | --- | --- |
| T01 - Authentication | Use each of the five README accounts with DemoPass!2026. | Successful login and correct role Home; last-use notice. All accounts pre-created. |
| T02 - Authentication | Incorrect password for existing user; nonexistent username; disabled account; injected username. | Same exact "Invalid username and/or password" message for every login failure; no dashboard. |
| T03 - Authentication | For client2, enter Wrong!123 four times, inspect as admin, then submit a fifth failure. | After four failures role remains 2; fifth sets Role 1/locked. Correct password now fails. |
| T04 - Authentication | Restart after lockout; admin logs in and re-enables client2 after offline identity verification. | Lock survives restart; unlock restores previous active role and resets counter; correct login succeeds. |
| T05 - Authentication | One failed login, then correct login, then another correct login. | First success reports prior FAILURE/time; next reports prior SUCCESS/time. Failure counter resets. |
| T06 - Authentication | Inspect Login, Register and Change My Password/current/new/confirm inputs visually. | All passwords masked; passwords not printed; fields clear after use. Visual desktop check pending. |
| T07 - Authentication | Create new client with Aa1!aaaa (8 chars); try 7 chars, 65 chars, no uppercase, no lowercase, no digit, no symbol, whitespace, or mismatch. | 8/64 boundaries accepted when compliant; all invalid cases rejected and logged without an account write. |
| T08 - Authentication | Inspect users.password in a disposable DB or admin list. | Database has versioned PBKDF2 hashes with different salts; UI only fixed placeholders, no hashes/plaintext. |
| T09 - Authentication | Change My Password with wrong current password, then with correct current password and compliant new password. | Wrong reauthentication denies and logs out; correct change succeeds, invalidates sessions and logs out. Old password fails. |
| T10 - Authentication | Admin selects another user > Change Password; supply admin current password. | Only admin can reset another account. Fresh reauthentication required; target sessions invalidated; account lock state is not silently cleared. |
| T11 - Authorization | From unauthenticated state call product, history, user and log service methods (automated test). | Every operation rejects and logs access violation; no protected data returned. |
| T12 - Authorization | Sign in separately as each role and inspect available home/navigation/actions. | Permissions exactly match matrix. Admin has no product/purchase/history business access. |
| T13 - Authorization | Client invokes product mutation/admin route; Staff invokes history/users/logs; Admin invokes products (automated direct calls). | Denied even when bypassing hidden buttons; timestamped ACCESS_VIOLATION recorded. |
| T14 - Authorization | client1 buys a product; client2 views/searches history for client1; manager views history. | client2 cannot see client1 records, including search; manager sees both customers. |
| T15 - Authorization | Admin changes a logged-in staff member role from a second service instance. | Previously authenticated session is rejected on its next operation; fresh login uses updated role. |
| T16 - Authorization | Delete a client with purchases, recreate same username and sign in. | New account does not inherit old history; manager can still review historical records. |
| T17 - Authorization | Admin changes role, disables/unlocks and deletes a disposable user; attempts self-deletion. | Changes persist; unlock restores prior role; deleted user denied. Self-deletion/role changes denied. |
| T18 - Data Validation | Username with apostrophe/SQL text, whitespace, 2 chars or 33 chars. | Entire value rejected, never cleaned into an acceptable username; validation failure logged. |
| T19 - Data Validation | Try product text <script>, negative stock, huge integer, fractional stock, NaN, Infinity, exponent price, 0 price, 3 decimal places. | Entire operation rejected with safe message; no partial business writes. |
| T20 - Data Validation | Add max stock 100000 and price 1000000.00; try stock 100001, price 1000000.01; invalid role 6/03. | Boundary values accepted; out-of-range/noncanonical role rejected and logged. |
| T21 - Data Validation | Search history using SQL text or 65 characters. | Rejected and logged; input cannot modify SQL or broaden customer ownership. |
| T22 - Data Validation | Purchase zero, negative, more than available, then a valid quantity. | Invalid requests leave stock/history unchanged; valid request decrements stock and creates history atomically. |
| T23 - Business Integrity | Rename/change price/delete a previously purchased product. | History still shows original name, quantity, unit price and total; it does not depend on the live catalog. |
| T24 - Business Integrity | Two service instances concurrently purchase the last unit (automated). | Exactly one succeeds; stock never negative; no duplicate oversold purchase. |
| T25 - Error Handling | Use test trigger to fail history insert after stock update in a disposable database. | Generic error, rollback restores stock, no partial purchase, session cleared. |
| T26 - Error Handling | Rename users table after login in a disposable database (automated). | Authorization cannot read state, so denies and clears session. Login also returns generic failure. |
| T27 - Error Handling | In desktop demo, cause an unexpected callback failure only in an isolated test build or make the demo DB unavailable. | No stack trace/SQL details; safe Login or startup alert with no protected content. Desktop navigation check pending. |
| T28 - Logging | Perform invalid input, successful/failed login and denied access; sign in as admin and refresh logs. | Each category has timestamp and actor (or anonymous for invalid actor); passwords/raw hostile payloads absent. |
| T29 - Logging | Client attempts read/clear logs; admin clears after confirmation. | Client denied; admin clear succeeds and leaves a LOG_CLEAR audit record. |
| T30 - Distribution | Copy dist alone to a writable directory; launch JAR from a different working directory; log in and purchase. | JAR locates its own database and bundled JDBC library. Packaged service smoke passes; full desktop launch must be checked locally. |
| T31 - NetBeans | Open original project, select JDK, Clean and Build, then Run. | All forms/classes compile; role workflows run; rebuilt dist includes dependency and DB. NetBeans GUI run pending on user machine. |

## 5. Checklist traceability (29 items / 58 possible points)

| Item | Requirement | Implementation evidence | Demo cases |
| --- | --- | --- | --- |
| 1.1.1 | Administrator account | README; both demo databases; DistributionSmoke | T01 |
| 1.1.2 | Internal staff / manager accounts | README; both demo databases; DistributionSmoke | T01 |
| 1.1.3 | Standard client account | README; both demo databases; DistributionSmoke | T01 |
| 2.1.1 | Authentication on protected panels/resources | SQLite.require; AccessControl; Frame/*Home | T11-T13 |
| 2.1.2 | Authentication fails securely | SQLite.login/authenticate/transaction | T02,T26 |
| 2.1.3 | Strong one-way salted passwords | PasswordUtils; hashed demo fixtures | T08 |
| 2.1.4 | Generic authentication failures | SQLite.AUTH_FAILURE; Frame.loginAction | T02 |
| 2.1.5 | Password complexity | SQLite.password | T07 |
| 2.1.6 | Password minimum and maximum | SQLite.password (8-64) | T07 |
| 2.1.7 | Masked password entry | JPasswordField; updated .form files | T06 |
| 2.1.8 | Exactly five failures to Role 1 | SQLite.authenticate | T03-T04 |
| 2.1.9 | Last-use timestamp/status | SQLite.previousUse; Frame.loginAction | T05 |
| 2.1.10 | Reauthentication before password change | SQLite.changePassword; PasswordDialog | T09-T10 |
| 2.2.1 | Single authorization component | AccessControl.allowlist + SQLite.require | T11-T13 |
| 2.2.2 | Role logic and UI visibility | AccessControl; Frame; role homes; MgmtProduct | T12-T17 |
| 2.2.3 | Authorization fails securely | SQLite.require/transaction; session invalidation | T15,T26 |
| 2.2.4 | Correct role Home | Frame.mainNav/showHome; role home guard | T01,T12 |
| 2.3.1 | Reject all invalid input without cleaning | SQLite validation methods | T07,T18-T22 |
| 2.3.2 | Numeric ranges | SQLite.quantity/price/setRole | T19-T22 |
| 2.3.3 | Maximum input lengths | SQLite validators; README policy | T07,T18-T21 |
| 2.3.4 | PreparedStatements | SQLite.statement/update and all query methods | T18,T21 + source review |
| 2.4.1 | No end-user stack traces | Main event boundary; AppException; Frame.safeFailure | T25-T27 |
| 2.4.2 | Generic Java/SQLite errors | SQLite.transaction; Frame.safeFailure | T25-T27 |
| 2.4.3 | Prevent controller/database crashes | Transaction wrapper; Main startup/event handling | T25-T27 |
| 2.4.4 | Safe unprivileged error state | logout; Frame.loginNav/clearData; Main startup handler | T25-T27 |
| 2.5.1 | Logs exclusively Role 5 | AccessControl.LOGS; SQLite.getLogs/clearLogs | T28-T29 |
| 2.5.2 | Log validation failures | SQLite.reject; authentication input validation | T18-T22,T28 |
| 2.5.3 | Log all authentication attempts | SQLite.authenticate; including unknown/disabled/reauth | T02-T05,T28 |
| 2.5.4 | Log unauthorized access | SQLite.require; shared panel authorization | T11-T13,T28 |

All rows have implemented controls and a demo procedure. The 140-check regression output supports service behavior and Swing panel construction/population; it does not substitute for observing password dots, modal dialogs, top-level window navigation, or NetBeans on the presentation computer. No Complete/2 marks or 58/58 score are asserted here.

## 6. Run, reset and verification notes

Run dist/run.bat on Windows, sh dist/run.sh on Linux, or java -jar dist/CSSECDV.jar. Keep lib/ and database.db beside the JAR. Demo accounts admin (5), manager (4), staff (3), client1/client2 (2) all use DemoPass!2026; each password has a distinct salt. Use only for the classroom demo. The fresh fixture has 3 products and no history/logs. Normal startup never resets or recreates accounts.

Build: build.bat test on Windows, sh build.sh test on Linux with JDK tools on PATH. NetBeans opens the existing build.xml project and uses the project-root database; packaged JAR uses dist/database.db. These are independent copies. Builds preserve an existing runtime database; NetBeans Clean removes dist, so back up any activity before cleaning. Copy an untouched submitted demo DB to reset a disposable presentation copy.

Observed environment: Linux x86-64, OpenJDK 21.0.13. Source compiled to Java 8 bytecode with -source 8 -target 8; Java 8 runtime compatibility was not independently tested. All 140 regression checks passed with real SQLite and headless Swing panels. Packaged-JAR smoke passed all five account roles, catalog, purchase and history, JDBC native loading and beside-JAR database resolution from another working directory. See test-results.txt and distribution-test-results.txt.

Not performed: full desktop UI clicking/visual inspection, Windows runtime, NetBeans IDE Clean/Build/Run, or a production security/dependency audit. Before the live demo, execute T06, T12, T27, T30 and T31 on the actual computer. An implementation can be tested thoroughly without claiming an unobserved GUI result.

Legacy handling: schema upgrades inspect columns separately and preserve supported hashes. Unsupported/plaintext credentials are replaced with random hashes and disabled, including any legacy admin. Use the provided new fixture for this project; an existing real installation needs a separately trusted recovery process. Legacy history ownership is backfilled once to existing user IDs. New purchases always include immutable account IDs and unit prices. Missing historical prices display Unavailable rather than inventing values.

Local trust boundary: someone with unrestricted filesystem/process access can modify SQLite or program code; application roles do not protect against the OS owner. Keep the folder writable only by intended OS users. Audit logs are application-restricted, not cryptographically tamper-proof; admin can clear them, leaving a clear event. When database storage is inaccessible, logging cannot persist and operations fail closed. The original SQLite JDBC 3.23.1 dependency was retained for starter compatibility; production dependency modernization was not verified.

## 7. References and submission review

Primary requirements: the two user-supplied PDFs named above. Repository: https://github.com/owensanluis/PeanutButter. Password-storage reference: OWASP Password Storage Cheat Sheet, https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html (consulted 17 November 2026). PBKDF2-HMAC-SHA256 uses a 600000-iteration work factor here; the implementation details are in PasswordUtils.java.

Submission contents: complete src/ and nbproject/, build files, test source, required documentation in PDF and editable Markdown, and dist/ containing executable JAR, dependency, database and launchers. Fill group names/section on the course checklist and capture any screenshots requested by your instructor after the local demo. Source and binaries should be submitted together.
